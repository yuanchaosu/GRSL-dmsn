# -*- coding: utf-8 -*-
"""
training configuration
"""

import argparse
import torch
import os
import datetime

parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)

### common parameters
'''Whisper=8 Houston18=10 Chikusei=16'''
parser.add_argument('--scale_factor',type=int,default=4, help='Whisper=8 Houston18=10 TG=12 Chikusei=16')
parser.add_argument('--data_name',type=str, default="wadc",help='Whisper Houston18 TG Chikusei  ')
parser.add_argument('--sp_root_path',type=str, default='data/DMSN/spectral_response/',help='where you store your own spectral response')
parser.add_argument('--default_datapath',type=str, default="data/DMSN/",help='where you store your HSI data file and spectral response file')
parser.add_argument('--batchsize',type=int, default=1,help='')
parser.add_argument("--gpu_ids", type=str, default='0', help='gpu ids: e.g. 0;1;2')
parser.add_argument("--read_real_data", type=str, default='No', help='No即仿真数据，Yes即真实数据')
#parser.add_argument('--checkpoints_dir',type=str, default='checkpoints',help='where store the training results')




parser.add_argument('--epoch_count', type=int, default=1, help='the starting epoch count, we save the model by <epoch_count>, <epoch_count>+<save_latest_freq>, ...')
parser.add_argument('--niter', type=int, default=7000, help='# of iter at starting learning rate')
parser.add_argument('--niter_decay', type=int, default=7000, help='# of iter to linearly decay learning rate to zero')
parser.add_argument('--lr_policy', type=str, default='lambda', help='learning rate policy: lambda|step|plateau')
parser.add_argument('--lr_decay_iters', type=int, default=100, help='multiply by a gamma every lr_decay_iters iterations')
parser.add_argument('--lr_decay_gamma', type=float, default=0.8)
parser.add_argument('--lr_decay_patience', type=int, default=50)
parser.add_argument('--print_freq', type=int, default=10)

parser.add_argument('--display_ncols', type=int, default=2, help='if positive, display all images in a single visdom web panel with certain number of images per row.')
parser.add_argument('--display_winsize', type=int, default=256, help='display window size')
parser.add_argument('--display_id', type=int, default=1, help='window id of the web display')
parser.add_argument('--display_server', type=str, default="http://localhost", help='visdom server of the web display')
parser.add_argument('--display_env', type=str, default='main', help='visdom display environment name (default is "main")')
parser.add_argument('--display_port', type=int, default=8100, help='visdom port of the web display')
###
parser.add_argument("--S1_lr", type=float, default=0.001)
parser.add_argument("--S2_lr", type=float, default=0.0011)

#parser.add_argument('--use_psf_gt', type=str, default="Yes", help='')
#parser.add_argument('--use_srf_gt', type=str, default="Yes", help='')




parser.add_argument('--two_stream_activation', type=str, default="No", help='sigmoid,softmax,clamp,No')
parser.add_argument('--shared_stream_activation', type=str, default="No", help='sigmoid,softmax,clamp,No')
parser.add_argument('--plus_activation', type=str, default="clamp", help='sigmoid,softmax,clamp,No')
parser.add_argument('--abun2img_activation', type=str, default="clamp", help='sigmoid,clamp')

parser.add_argument('--Pixelwise_avg_crite', type=str, default="No", help='')

parser.add_argument('--lambda_A', type=float, default=100,help='hr_msi 重建误差')   #100
parser.add_argument('--lambda_B', type=float, default=100,help='lr_hsi 重建误差')    #100
parser.add_argument('--lambda_C', type=float, default=10,help='从预测的hr_hsi恢复到hr_msi\lr_hsi的误差')  #10
parser.add_argument('--lambda_D', type=float, default=1,help='两个丰度之间的误差')  #1
parser.add_argument('--lambda_E', type=float, default=0.01,help='abundance_sum2one')  #0.01

#参数分析
parser.add_argument('--block_num', type=int, default=3, help='')
parser.add_argument('--endmember_num', type=int, default=160, help='visdom port of the web display')
#消融实验
parser.add_argument('--use_perceptual_loss', type=str, default="No", help='Yes ,No')
parser.add_argument('--use_semi_siamese', type=str, default="Yes", help='Yes ,No')
parser.add_argument('--blind', type=str, default="Yes", help='Yes ,No')

#添加噪声
parser.add_argument('--noise', type=str, default="No", help='Yes ,No')
parser.add_argument('--nSNR', type=int, default=25)




args=parser.parse_args()

device = torch.device(  'cuda:{}'.format(args.gpu_ids)  ) if  torch.cuda.is_available() else torch.device('cpu') 
args.device=device
# Because the full width at half maxima of Gaussian function used to generate the PSF is set to scale factor in our experiment, 
# there exists the following relationship between  the standard deviation and scale_factor :
args.sigma = args.scale_factor / 2.35482

t=str(datetime.datetime.now().day)+str("_") + str(datetime.datetime.now().hour)+str("_") + str(datetime.datetime.now().minute)+str("_") + \
                   str(datetime.datetime.now().second)
args.expr_dir=os.path.join('checkpoints', args.data_name+'_SF'+str(args.scale_factor)+'_endnum'+str(args.endmember_num)+\
                           '_A'+str(args.lambda_A)+'_B'+str(args.lambda_B)+'_C'+str(args.lambda_C)+\
                           '_D'+str(args.lambda_D)+'_E'+str(args.lambda_E) + '_' + 'block_num_'+str(args.block_num) +\
                            '_use_per' + args.use_perceptual_loss + '_use_semi' + args.use_semi_siamese + '_blind' + args.blind
                           )
#args.name = args.data_name+'_SF'+str(args.scale_factor)+'_sigma'+str(args.sigma)+'_lr'+str(args.lr) 

'''+ \
                     '_nums'+str(opt.num_theta)+'_niter'+str(opt.niter)+'_decay'+str(opt.niter_decay) + \
                    '_A'+str(opt.lambda_A)+'_B'+str(opt.lambda_B)+'_C'+str(opt.lambda_C)+\
                    '_D'+str(opt.lambda_D)+'_E'+str(opt.lambda_E)+'_F'+str(opt.lambda_F)
'''

