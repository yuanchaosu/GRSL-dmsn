# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 10:54:25 2024

@author: 13572
"""
import numpy as np
import scipy.io as sio
import os
import torch
import torch.nn.functional as fun
import torch.utils.data as data
import torch.nn as nn
import torch.optim as optim
from read_data import readdata
#import evaluation
from evaluation import compute_sam,compute_psnr,compute_ergas,compute_cc,compute_rmse
from utils import print_current_precision
import random
import matplotlib.pyplot as plt

'''
class generate_srf_attention(nn.Module):
    def __init__(self ,hs_bands,ms_bands):
        super().__init__()
        #input (1,2,6,6)
        self.hs_bands=hs_bands
        self.ms_bands=ms_bands
        #B,C,H,W=input.shape[0],input.shape[1],input.shape[2],input.shape[3]
        middle=10
        self.layer1=nn.Sequential(
            nn.AdaptiveAvgPool2d(output_size=(1, 1)), 
            nn.Conv2d(self.hs_bands,middle,kernel_size=1,bias=False) ,
            #nn.ReLU(inplace=True)
            #nn.Sigmoid()
        )
        
        self.layer2 = nn.ModuleList()
        for i in range(self.ms_bands):
            self.layer2.append(nn.Conv2d(middle,self.hs_bands,kernel_size=1,bias=False)) 
 
    def forward(self,input):
       x=self.layer1(input) #(1,middle,1,1)
       #print("attention_psf",attention_psf.shape)
       out=[]
       for i in range(self.ms_bands):
           
           #w = self.layer2[i](x).data    
           #w.clamp_(0.0, 10.0)
           #div=1/(w.sum())
           #srf=div*w
           #out.append(srf)
           
           out.append(self.layer2[i](x))
       srf_map=torch.cat(out, dim=0) # ms_band X hs_band X 1 X 1
       return  srf_map
'''

class Predict_lr_msi_fhsi(nn.Module):
    def __init__(self, hs_bands,ms_bands):
        super(Predict_lr_msi_fhsi, self).__init__()
        self.hs_bands=hs_bands
        self.ms_bands=ms_bands
        
        r = 2
        self.layer1 = nn.ModuleList()
        
        
        for i in range(self.ms_bands):
            self.layer1.append(
                
               nn.Sequential(
                   nn.AdaptiveAvgPool2d(1),
                   nn.Conv2d(in_channels=hs_bands, out_channels=int(hs_bands/r), kernel_size=1)  ,
                   #nn.Sigmoid(),
                   nn.ReLU(inplace=True),
                   #nn.Conv2d(1,1,kernel_size=3,stride=1,padding=1,bias=False),
                   #nn.Sigmoid(),
                   nn.Conv2d(in_channels=int(hs_bands/r), out_channels=hs_bands, kernel_size=1),
                   nn.Softmax(dim=1)
                             )
                              ) 
        

    def forward(self, input):
            SRF_all=[] #ms_band个 1 X 46 X 1 X 1大小的SRF
            out=[]
            for i in range(self.ms_bands):
                SRF=self.layer1[i](input) #expand_as之前大小为1 46 1 1
                SRF_all.append(SRF) #ms_band个 1 X 46 X 1 X 1大小的SRF
                SRF_expand=SRF.expand_as(input) #expand_as之前大小为1 46 1 1 ，as之后为  1 46 30 30
                band    = torch.sum(input*SRF_expand, dim=1,keepdim=True) # 1 1 30 30
                out.append(band)
                
            output=torch.cat(out, dim=1) # 1 X ms_band X H X W
            SRF_out=torch.cat(SRF_all, dim=0) # ms_band X hs_band X 1 X 1
            return output,SRF_out
        




class BlurDown(object):
    def __init__(self):
        #self.shift_h = shift_h
        #self.shift_w = shift_w
        #self.stride = stride
        pass

    def __call__(self, input_tensor, psf, ratio):
        B,C,H,W=input_tensor.shape[0],input_tensor.shape[1],input_tensor.shape[2],input_tensor.shape[3]
        if psf.shape[0] == 1:
            psf = psf.repeat(C, 1, 1, 1) #8X1X8X8
        
        '''
        if self.stride == 0:
            output_tensor = fun.conv2d(input_tensor, psf, None, (1, 1),  groups=groups) #不改变像素个数 
            #input_tensor:  torch.Size([1, 8, 240, 240])
            #psf:           torch.Size([8, 1, 15, 15])
            #groups         8
            output_tensor = output_tensor[:, :, self.shift_h:: ratio, self.shift_h:: ratio] #改变像素个数
        '''
        
        output_tensor = fun.conv2d(input_tensor, psf, None, (ratio, ratio),  groups=C) #ratio为步长 None代表bias为0，padding默认为无
        return output_tensor
    
class BlindNet(nn.Module):
    def __init__(self, hs_bands, ms_bands, ker_size, ratio):
        super().__init__()
        self.hs_bands = hs_bands
        self.ms_bands = ms_bands
        self.ker_size = ker_size #8
        self.ratio = ratio #8
        
        #psf = torch.rand([1, 1, self.ker_size, self.ker_size]) #0-1均匀分布
        psf = torch.ones([1, 1, self.ker_size, self.ker_size]) * (1.0 / (self.ker_size ** 2))
        self.psf = nn.Parameter(psf)
        
        self.attention_srf=Predict_lr_msi_fhsi(self.hs_bands,self.ms_bands)
        #srf = torch.rand([self.ms_bands, self.hs_bands, 1, 1]) #0-1均匀分布
        #srf = torch.ones([self.ms_bands, self.hs_bands, 1, 1]) * (1.0 / self.hs_bands) 
        #self.srf = nn.Parameter(srf)
        self.blur_down = BlurDown()

    def forward(self, lr_hsi, hr_msi):
        '''
        srf_div = torch.sum(self.srf, dim=1, keepdim=True) # 8 x 1x 1 x 1
        #print('srf_div',srf_div,srf_div.shape)  #
        srf_div = torch.div(1.0, srf_div)     #8 x 1x 1 x 1
        #print('srf_div',srf_div,srf_div.shape)
        srf_div = torch.transpose(srf_div, 0, 1)  # 1 x l x 1 x 1    1 x 8 x 1 x 1
        #print('srf_div',srf_div,srf_div.shape)
        '''
        '''
        lr_msi_fhsi,SRF_out=self.attention_srf(lr_hsi)
        #lr_msi_fhsi = fun.conv2d(lr_hsi, self.attention_map_srf, None) #(1,8,30, 30)
        #lr_msi_fhsi = torch.mul(lr_msi_fhsi, srf_div) #element-wise broadcast Ylow:1X8X30X30
        self.lr_msi_fhsi = torch.clamp(lr_msi_fhsi, 0.0, 1.0)
        self.srf_est=SRF_out # ms_band X hs_band X 1 X 1
        '''
        self.lr_msi_fhsi,self.srf_est=self.attention_srf(lr_hsi)
        
        
        
        self.lr_msi_fmsi = self.blur_down(hr_msi, self.psf, self.ratio)
        #lr_msi_fmsi = torch.clamp(lr_msi_fmsi, 0.0, 1.0)
        return  self.lr_msi_fhsi, self.lr_msi_fmsi


class Blind(readdata):
    def __init__(self, args):
        super().__init__(args)
        #self.strBR = 'BR.mat'
        # set
        #self.args=args 在父类定义了
        
        self.S1_lr = self.args.S1_lr
        self.ker_size = self.args.scale_factor  #8
        self.ratio    = self.args.scale_factor 
        self.hs_bands = self.srf_gt.shape[0]
        self.ms_bands = self.srf_gt.shape[1]
        # variable, graph and etc.
        #self.__hsi = torch.tensor(self.hsi)
        #self.__msi = torch.tensor(self.msi)
        self.model = BlindNet(self.hs_bands, self.ms_bands, self.ker_size, self.ratio).to(self.args.device)
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.S1_lr)
        

    def train(self, max_iter=4000, verb=True):
        
        #hsi, msi = self.__hsi.cuda(), self.__msi.cuda()
        lr_hsi, hr_msi = self.tensor_lr_hsi.to(self.args.device), self.tensor_hr_msi.to(self.args.device)
        for epoch in range(1, max_iter+1):
            lr_msi_fhsi_est, lr_msi_fmsi_est = self.model(lr_hsi, hr_msi)
            #Ylow, Zlow = self.model(lr_hsi, hr_msi)
            
            loss = torch.sum(torch.abs(lr_msi_fhsi_est - lr_msi_fmsi_est))
            
                    
            self.optimizer.zero_grad()
            loss.backward()
            
            #print('更新之前',torch.sum(self.model.srf, dim=1, keepdim=True))
            
            self.optimizer.step()
            #print('更新之前',torch.sum(self.model.srf, dim=1, keepdim=True))
            #self.model.apply(self.check_weight(epoch=epoch,max_iter=max_iter))
            self.model.apply(self.check_weight)
            #print('更新之前',torch.sum(self.model.srf, dim=1, keepdim=True))
            
            with torch.no_grad():
                if verb is True:
                    if (epoch ) % 1000 == 0:
                        
                        info='epoch: %s, lr: %s, loss: %s' % (epoch, self.S1_lr, loss)
                        print(info)
                        print_current_precision(self.args,info)
                        
                        lr_msi_fhsi_est_numpy=lr_msi_fhsi_est.data.cpu().detach().numpy()[0].transpose(1,2,0)
                        lr_msi_fmsi_est_numpy=lr_msi_fmsi_est.data.cpu().detach().numpy()[0].transpose(1,2,0)
                        self.lr_msi_fhsi_est_numpy=lr_msi_fhsi_est_numpy
                        self.lr_msi_fmsi_est_numpy=lr_msi_fmsi_est_numpy
                        train_message='生成的两个图像 train epoch:{} lr:{}\ntest:L1loss:{}, sam_loss:{}, psnr:{}, ergas:{}, CC:{}, rmse:{}\n'.\
                                  format(epoch,self.S1_lr,
                                         np.mean( np.abs( lr_msi_fhsi_est_numpy- lr_msi_fmsi_est_numpy ) ) ,
                                         compute_sam(lr_msi_fhsi_est_numpy, lr_msi_fmsi_est_numpy) ,
                                         compute_psnr(lr_msi_fhsi_est_numpy, lr_msi_fmsi_est_numpy) ,
                                         compute_ergas(lr_msi_fhsi_est_numpy, lr_msi_fmsi_est_numpy, self.ratio),
                                         compute_cc(lr_msi_fhsi_est_numpy, lr_msi_fmsi_est_numpy),
                                         compute_rmse(lr_msi_fhsi_est_numpy, lr_msi_fmsi_est_numpy)
                                             )
                        print(train_message)
                        print_current_precision(self.args,train_message)
                        
                        print('************')
                        test_message_SRF='SRF lr_msi_fhsi_est与lr_msi_fhsi epoch:{} lr:{}\ntest:L1loss:{}, sam_loss:{}, psnr:{}, ergas:{}, CC:{}, rmse:{}\n'.\
                                  format(epoch,self.S1_lr,
                                         np.mean( np.abs( self.lr_msi_fhsi- lr_msi_fhsi_est_numpy ) ) ,
                                         compute_sam(self.lr_msi_fhsi, lr_msi_fhsi_est_numpy) ,
                                         compute_psnr(self.lr_msi_fhsi, lr_msi_fhsi_est_numpy) ,
                                         compute_ergas(self.lr_msi_fhsi, lr_msi_fhsi_est_numpy,self.ratio),
                                         compute_cc(self.lr_msi_fhsi, lr_msi_fhsi_est_numpy),
                                         compute_rmse(self.lr_msi_fhsi, lr_msi_fhsi_est_numpy)
                                         )
                        print(test_message_SRF)
                        print_current_precision(self.args,test_message_SRF)
                        
                        print('************')
                        test_message_PSF='PSF lr_msi_fmsi_est与lr_msi_fmsi  epoch:{} lr:{}\ntest:L1loss:{}, sam_loss:{}, psnr:{}, ergas:{}, CC:{}, rmse:{}\n'.\
                                  format(epoch,self.S1_lr,
                                         np.mean( np.abs( self.lr_msi_fmsi- lr_msi_fmsi_est_numpy ) ) ,
                                         compute_sam(self.lr_msi_fmsi, lr_msi_fmsi_est_numpy) ,
                                         compute_psnr(self.lr_msi_fmsi, lr_msi_fmsi_est_numpy) ,
                                         compute_ergas(self.lr_msi_fmsi, lr_msi_fmsi_est_numpy,self.ratio),
                                         compute_cc(self.lr_msi_fmsi, lr_msi_fmsi_est_numpy),
                                         compute_rmse(self.lr_msi_fmsi, lr_msi_fmsi_est_numpy) 
                                         )
                        print(test_message_PSF)
                        print_current_precision(self.args,test_message_PSF)
                        
                        
                        
                        psf_info="estimated psf \n {} \n psf_gt \n{}".format(
                            np.squeeze(self.model.psf.data.cpu().detach().numpy()),
                            self.psf_gt 
                            )
                        #print(psf_info)
                        print_current_precision(self.args,psf_info)
                       
                        srf_info="estimated srf \n {} \n srf_gt \n{}".format(
                            np.squeeze(self.model.srf_est.data.cpu().detach().numpy()).T,
                            self.srf_gt 
                            )
                        #print(srf_info)
                        print_current_precision(self.args,srf_info)
                        
                        
                        #####从目标高光谱空间下采样####
                        lr_hsi_est=self.model.blur_down(self.tensor_gt.to(self.args.device), self.model.psf, self.ratio)
                        lr_hsi_est_numpy=lr_hsi_est.data.cpu().detach().numpy()[0].transpose(1,2,0)
                
                        print('************')
                        from_hrhsi_PSF='PSF lr_hsi_est与lr_hsi  epoch:{} lr:{}\ntest:L1loss:{}, sam_loss:{}, psnr:{}, ergas:{}, CC:{}, rmse:{}\n'.\
                                  format(epoch,self.S1_lr,
                                         np.mean( np.abs( self.lr_hsi- lr_hsi_est_numpy ) ) ,
                                         compute_sam(self.lr_hsi, lr_hsi_est_numpy) ,
                                         compute_psnr(self.lr_hsi, lr_hsi_est_numpy) ,
                                         compute_ergas(self.lr_hsi, lr_hsi_est_numpy,self.ratio),
                                         compute_cc(self.lr_hsi, lr_hsi_est_numpy),
                                         compute_rmse(self.lr_hsi, lr_hsi_est_numpy) 
                                         )
                        print(from_hrhsi_PSF) 
                        #####从目标高光谱空间下采样####
                        #####从目标高光谱光谱下采样####
                        srf_est=np.squeeze(self.model.srf_est.data.cpu().detach().numpy()).T
                        w,h,c = self.gt.shape
                        if srf_est.shape[0] == c:
                            hr_msi_est_numpy = np.dot(self.gt.reshape(w*h,c), srf_est).reshape(w,h,srf_est.shape[1])
                        print('************')
                        from_hrhsi_SRF='SRF hr_msi_est与hr_msi  epoch:{} lr:{}\ntest:L1loss:{}, sam_loss:{}, psnr:{}, ergas:{}, CC:{}, rmse:{}\n'.\
                                  format(epoch,self.S1_lr,
                                         np.mean( np.abs( self.hr_msi- hr_msi_est_numpy ) ) ,
                                         compute_sam(self.hr_msi, hr_msi_est_numpy) ,
                                         compute_psnr(self.hr_msi, hr_msi_est_numpy) ,
                                         compute_ergas(self.hr_msi, hr_msi_est_numpy,self.ratio),
                                         compute_cc(self.hr_msi, hr_msi_est_numpy),
                                         compute_rmse(self.hr_msi, hr_msi_est_numpy) 
                                         )
                        print(from_hrhsi_SRF)        
                        #####从目标高光谱光谱下采样####
                        
                        print("____________________________________________")
                        print_current_precision(self.args,"____________________________________________")
                        
                        #print(self.model.attention_srf.layer1[1].weight[1:5,0,0,0])
                        #print(self.model.attention_srf.layer2[0].weight[1:4,0,0,0])
                        #print(self.model.attention_srf.layer1[1].weight.grad)
                        #print(self.model.attention_srf.layer2[0].weight.grad)
                        '''
                        print(self.model.psf)
                        print(self.model.psf.grad)
                        print(self.model.srf[:,0,0,0])
                        print(self.model.srf.grad[:,0,0,0])
                        print((self.lr_msi_fhsi).sum())
                        '''
                        '''
                        print(np.squeeze(self.model.psf.data.cpu().detach().numpy()))
                        print("~~~~~~~~~")
                        print(self.psf_gt)
                        print("~~~~~~~~~")
                        #print(abs(np.squeeze(self.model.psf.data.cpu().detach().numpy())-self.psf_gt))
                        
                        print(np.squeeze(self.model.srf.data.cpu().detach().numpy()).T[:,1])
                        print("~~~~~~~~~")
                        print(self.srf_gt[:,1])
                        '''
        #torch.save(self.model.state_dict(), self.model_save_path + 'parameter.pkl')
        
        PATH=os.path.join(self.args.expr_dir,self.model.__class__.__name__+'.pth')
        torch.save(self.model.state_dict(),PATH)
        #self.psf = torch.tensor(torchkits.to_numpy(self.model.psf.data))
        #self.srf = torch.tensor(torchkits.to_numpy(self.model.srf.data))

    def get_save_result(self, is_save=True):
        
        #self.model.load_state_dict(torch.load(self.model_save_path + 'parameter.pkl'))
        psf = self.model.psf.data.cpu().detach().numpy() ## 1 1 15 15
        srf = self.model.srf_est.data.cpu().detach().numpy() # 8 46 1 1
        psf = np.squeeze(psf)  #15 15
        srf = np.squeeze(srf).T  # b x B 8 X 46 变为 46X8 和srf_gt保持一致
        self.psf, self.srf = psf, srf
        '''
        if is_save is True:
            PATH_psf=os.path.join(self.args.expr_dir,'psf_est')
            PATH_srf=os.path.join(self.args.expr_dir,'srf_est')
            sio.savemat(PATH_psf, {'psf_est': self.psf})
            sio.savemat(PATH_srf, {'srf_est': self.srf})
        return
        '''
        if is_save is True:
            sio.savemat(os.path.join(self.args.expr_dir , 'estimated_psf_srf.mat'), {'psf_est': psf, 'srf_est': srf})
            
    @staticmethod
    def check_weight(model):
        
        if hasattr(model, 'psf'):
            #print('psf___________')
            w = model.psf.data
            w.clamp_(0.0, 1.0)
            psf_div = torch.sum(w)
            psf_div = torch.div(1.0, psf_div)
            w.mul_(psf_div)
        if hasattr(model, 'srf'):
            print('srf____________')
            w = model.srf.data # torch.Size([8, 46, 1, 1])        
            w.clamp_(0.0, 10.0)
            srf_div = torch.sum(w, dim=1, keepdim=True) #torch.Size([8, 1, 1, 1])
            srf_div = torch.div(1.0, srf_div) #torch.Size([8, 1, 1, 1])
            w.mul_(srf_div)
            
if __name__ == "__main__":
    from config import args
    def setup_seed(seed):
         torch.manual_seed(seed)
         torch.cuda.manual_seed_all(seed)
         np.random.seed(seed)
         random.seed(seed)
         torch.backends.cudnn.deterministic = True

    setup_seed(20)
    blind = Blind(args)
    
    blind.train()
    #blind.model.srf.data.clamp_(0.0001, 10.0)
    #blind.model.attention_map_srf.data[blind.model.attention_map_srf.data<0.0001]=0
    
    psf_est=np.squeeze(blind.model.psf.data.cpu().detach().numpy())
    psf_gt=blind.psf_gt
    
    srf_est=np.squeeze(blind.model.srf_est.data.cpu().detach().numpy()).T
    srf_gt=blind.srf_gt
    #blind.get_save_result()
    