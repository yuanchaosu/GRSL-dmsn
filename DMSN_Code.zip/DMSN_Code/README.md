# DMSN: A Deep Multi-Stream Network for Unsupervised Hyperspectral Image Super-Resolution

---------------------------------------------------------------------------------------------------
Authors: Sheng Li, Yuanchao Su*, Xu Sun, Jiaxin Li, Boyan Li, Jianjian Gao, Xiaohua Feng, and Mengying Jiang

## Implementation Details:
The proposed DMSN on a Windows operating system using Python 3.11.5 and Pytorch 1.12.1 to compare our method with other deep learning-based methods.
The training was performed on an NVIDIA GPU GeForce GTX 4060Ti. the Adam optimizer was used to minimize training loss with a weight decay of 0.0001. 
we set the total epoch to 14,000. The learning rate was 0.001.
 
## Dependencies
- **Python 3.11.5**
- **PyTorch 1.12.1**
- **Visdom**
- **NumPy**
- **SciPy**
- **Matplotlib**
<img src="./imgs/Fig1.png" width="666px"/>
**Fig.1.** Architecture of the proposed DMSN.
## Directory structure
<img src="./imgs/structure.png" width="200px"/>

**Fig.2.** Directory structure. There are six folders , one .py file and one .sh file in DMSN.
### checkpoints
This folder is used to store the training results.
### data
This folder is used to store the ground-true HHSI and corresponding spectral response of multispectral imager.[The dataset in the data folder can be downloaded here:](https://drive.google.com/drive/folders/1ugC19qzCnndyMbr0j9G1kxLSdHNqAHZF?usp=sharing)
The dataset is provided in the "data/DMSN" folder.
### model
This folder consists ten .py files, including `fusion.py`, `fusion_simple.py`, `network.py`,`evalution.py`,`network_psf.py`, `network_SRF.py`,`read_data.py`,`srf_psf_attention.py`,`srf_psf_layer.py`,and `__init__.py`.
### configuration
- `config.py`: all the parameters in our methed.

## Training

1. Start visdom first in one terminal
```
visdom --port=8097
```

2. Bring up the page localhost:8097 in your browser

3. Run shell file in another terminal
```
sh bash.sh
```
python main.py--data_name=Houston18 --scale_factor=16 --gpu_ids=0 --endmember_num=100--niter=7000 --niter_decay=7000 --lr_policy=lambda --lr_decay_gamma=0.8 
--lr_decay_iters=100 --display_port=8097 --lambda_A=100 --lambda_B=100 --lambda_C=100 --lambda_D=100 --lambda_E=100 --print_freq=20 --batchsize=1
