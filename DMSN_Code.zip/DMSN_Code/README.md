# DMSN: A Deep Multi-Stream Network for Unsupervised Hyperspectral Image Super-Resolution

---------------------------------------------------------------------------------------------------
Authors: Sheng Li, Yuanchao Su*, Xu Sun, Jiaxin Li, Boyan Li, Jianjian Gao, Xiaohua Feng, and Mengying Jiang

Implementation Details:
The proposed DMSN on a Windows operating system using Python 3.11.5 and Pytorch 1.12.1 to compare our method with other deep learning-based methods.
The training was performed on an NVIDIA GPU GeForce GTX 4080 SUPER. the Adam optimizer was used to minimize training loss with a weight decay of 0.0001. 
we set the total epoch to 14,000. The learning rate was 0.001.
 
## Dependencies
*TODO*

## Training

1. Start visdom first in one terminal
```
visdom --port=8097
```

2. Bring up the page localhost:8097 in your browser

3. Run shell file in another terminal
```
sh bash.sh
```
python main.py--data_name=Houston18 --scale_factor=16 --gpu_ids=0 --endmember_num=100--niter=7000 --niter_decay=7000 --lr_policy=lambda --lr_decay_gamma=0.8 
--lr_decay_iters=100 --display_port=8097 --lambda_A=100 --lambda_B=100 --lambda_C=100 --lambda_D=100 --lambda_E=100 --print_freq=20 --batchsize=1